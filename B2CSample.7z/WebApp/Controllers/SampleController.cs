﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Web;
using System.Threading.Tasks;
using TodoListClient.Services;

namespace TodoListClient.Controllers
{
    public class SampleController : Controller
    {
        private ISampleService _sampleService;

        public SampleController(ISampleService sampleService)
        {
            _sampleService = sampleService;
        }

        [AuthorizeForScopes(ScopeKeySection = "SampleList:SampleListScope")]
        public async Task<ActionResult> Index()
        {
            return View(await _sampleService.GetAsync());
        }

    }
}