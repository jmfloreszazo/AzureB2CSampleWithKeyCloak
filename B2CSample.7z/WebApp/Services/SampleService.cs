﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Identity.Web;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using WebAPIB2CSample.Models;

namespace TodoListClient.Services
{
    public static class SampleServiceExtensions
    {
        public static void AddSampleService(this IServiceCollection services, IConfiguration configuration)
        {
            //Please take it as demo, doing this in production is crazy.
            services.AddHttpClient<ISampleService, SampleService>();
        }
    }

    public class SampleService : ISampleService
    {
        private readonly IHttpContextAccessor _contextAccessor;
        private readonly HttpClient _httpClient;
        private readonly string _sampleScope = string.Empty;
        private readonly string _sampleBaseAddress = string.Empty;
        private readonly ITokenAcquisition _tokenAcquisition;

        public SampleService(ITokenAcquisition tokenAcquisition, HttpClient httpClient, IConfiguration configuration, IHttpContextAccessor contextAccessor)
        {
            _httpClient = httpClient;
            _tokenAcquisition = tokenAcquisition;
            _contextAccessor = contextAccessor;
            _sampleScope = configuration["SampleList:SampleListScope"];
            _sampleBaseAddress = configuration["SampleList:SampleListBaseAddress"];
        }
        

        public async Task<IEnumerable<Sample>> GetAsync()
        {
            await PrepareAuthenticatedClient();

            var response = await _httpClient.GetAsync($"{ _sampleBaseAddress}/api/sample");
            if (response.StatusCode == HttpStatusCode.OK)
            {
                var content = await response.Content.ReadAsStringAsync();
                IEnumerable<Sample> samplelist = JsonConvert.DeserializeObject<IEnumerable<Sample>>(content);

                return samplelist;
            }

            throw new HttpRequestException($"Invalid status code in the HttpResponseMessage: {response.StatusCode}.");
        }

        private async Task PrepareAuthenticatedClient()
        {
            var accessToken = await _tokenAcquisition.GetAccessTokenForUserAsync(new[] { _sampleScope });
            Debug.WriteLine($"access token-{accessToken}");
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }
        
    }
}